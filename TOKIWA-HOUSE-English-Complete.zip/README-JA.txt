TOKIWA HOUSE 英語版HTML一式
作成日：2026年10月2日

【内容】
・英語版14ページ（トップ、アプリ紹介6、解説記事3、About、Support、Privacy、Terms）
・日本語版14ページに「日本語／English」切り替えと検索エンジン向け言語情報を追加
・英語版専用のstyle.css
・公開中だった日本語HTMLのバックアップ

【アップロード手順】
1. ZIPを展開します。
2. GitHubで yukiotokiwa.github.io リポジトリを開きます。
3. index.html と style.css が見える一番上の階層で Add file → Upload files を選びます。
4. upload-contents フォルダの「中身」をアップロードします。
   index.html、about.html、support.html、privacy.html、terms.html、apps、guides、en です。
   upload-contents フォルダそのものを置かないでください。
5. Commit changes で確定します。
6. GitHub Pagesの更新完了後、以下を確認します。
   日本語：https://yukiotokiwa.github.io/
   英語：https://yukiotokiwa.github.io/en/
   日本語トップの「English」、英語トップの「日本語」を押し、切り替えを確認します。
   各アプリ紹介・解説・サポートページも確認します。

【大切な点】
・既存のappsフォルダやリポジトリ全体を削除しないでください。
  このZIP内のappsには紹介用HTMLだけが入っています。
  apps/4trmtr-web/ と apps/bookkeep-desk-web/ は現在のものを残します。
・日本語用の既存style.cssはそのまま使います。英語用はen/style.cssです。
・backup-original とこのREADMEはアップロード不要です。
・公開中の日本語HTMLを取得して作成しました。作成後にご自身で編集したページがある場合は、
  そのページを古い内容で上書きしないよう差分を確認してください。
・これは紹介サイトの英語版です。App Store説明文やアプリ本体は変更していません。
・ブラウザアプリは既存の公開先を開きます。BOOKKEEP DESKは日本語UIである旨を英語で明記しています。
・App Storeリンクは /jp/ を固定しない形式にしました。販売国の設定はApp Store Connect側で別途行います。
・既存の広告枠IDはそのまま引き継いでいます。実広告の配信・収益は今回の動作確認対象外です。
・プライバシーポリシーと利用規約は公開中の日本語本文の英訳で、元の更新日を保持しています。

【元に戻す場合】
backup-original の中身を同じ階層に上書きすると、日本語ページを取得時の状態に戻せます。
enフォルダは日本語ページと独立しているため、必要に応じて別途削除できます。

【確認状況】
英語・日本語の28ページと内部参照474件を静的に検証済みです。
日本語本文の保持、言語切り替え先、英語本文の翻訳漏れ、ページ内リンクを確認しました。
表示確認用ブラウザを取得できなかったため、スマートフォン・PCでの画面確認は未完了です。
公開後に表示と既存ブラウザアプリへの移動をご確認ください。

【構成】
upload-contents/
  index.html ほか日本語共通ページ
  apps/       日本語アプリ紹介6ページ
  guides/     日本語ガイド3ページ
  en/
    index.html
    style.css
    about.html
    support.html
    privacy.html
    terms.html
    apps/     英語アプリ紹介6ページ
    guides/   英語ガイド3ページ
backup-original/ 変更前の日本語HTML14ページ
